<?php  // tag php 
phpinfo(); 
?> 