<?php
$servername = "localhost";
$username = "nicola";
$password = "1234";
$dbname = "magazzino";
?>