<?php
session_start();

//redirect

header("location:protetta.php");
exit();

?>